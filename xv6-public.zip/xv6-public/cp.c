#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

char buf[512];

int main(int argc,char *argv[])
{
    if (argc <= 2) {
        printf(2, "cp: wrong number of arguments\n");
        exit();
    }

    int fd_r = open(argv[1], O_RDONLY);
    if (fd_r < 0) {
        printf(1, "cp: can't open file: %s\n", argv[1]);
        exit();
    }

    int fd_w;
    if((fd_w = open(argv[2], O_CREATE | O_WRONLY))<0)
    {
        printf(2,"cp: error while create '%s'\n", argv[1]);
        exit();
    }
    int n;

    while ( (n = read(fd_r, buf, sizeof(buf))) > 0) {
        write(fd_w, buf, n);
    }
    close(fd_r);
    close(fd_w);
    exit();
}