//#include "types.h"
//#include "stat.h"
//#include "user.h"
//#include "fcntl.h"
//
//char buf[512];
//
//int main(int argc,char *argv[])
//{
//    if (argc <= 2) {
//        printf(2, "mv: wrong number of arguments\n");
//        exit();
//    }
//
//    // read from file
//    int fd_r = open(argv[1], O_RDONLY);
//    if (fd_r < 0) {
//        printf(1, "mv: can't open file: %s\n", argv[1]);
//        exit();
//    }
//    if(fstat(fd_w, &st)>=0)
//    {
//        if (st.type == T_DIR) // if directory, we have non-zero
//        {
//            printf(2,"mv: cannot copy directory '%s'\n", argv[1]);
//            exit();
//        }
//    }
//
//    // write to
//    int fd_w;
//    if((fd_w = open(argv[2], O_CREATE | O_WRONLY))<0)
//
//    int n;
//
//
//    while ( (n = read(fd_r, buf, sizeof(buf))) > 0) {
//        write(fd_w, buf, n);
//    }
//    close(fd_r);
//    close(fd_w);
//    exit();
//}

#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

char buf[512];

int main(int argc,char *argv[])
{
//    char *buf;
//    buf=(char*)malloc(512*sizeof(char));

    struct stat st;
    if (argc <= 2) {
        printf(2, "mv: wrong number of arguments\n");
        exit();
    }

    int fd_r = open(argv[1], O_RDONLY);
    if (fd_r < 0) {
        printf(1, "mv: can't open file: %s. No such file or directory.\n", argv[1]);
        exit();
    }

    if(fstat(fd_r, &st)>=0)
    {
        if (st.type == T_DIR) // if directory, we have non-zero
        {
            printf(2,"mv: cannot copy directory '%s'\n", argv[1]);
            exit();
        }
    }

    char *temp;
    temp=(char*)malloc(512*sizeof(char));
    int fd_w = open(argv[2], O_CREATE | O_WRONLY);

    if(fstat(fd_w, &st)>=0)
    {
        if(st.type == T_DIR) // if directory, we have non-zero
        {

            strcpy (temp, argv[1]);
            strcpy (temp, "/");
            strcpy (temp, argv[2]);
            close(fd_w);
            if((fd_w = open(temp, O_CREATE | O_WRONLY))<0)
            {
                printf(2,"mv: error while create '%s'\n", temp);
                exit();
            }
        } else {
            if(fd_w<0)
            {
                printf(2,"mv: error while create '%s'\n", argv[2]);
                exit();
            }
        }
    }

    int n;

    while ( (n = read(fd_r, buf, sizeof(buf))) > 0) {
        write(fd_w, buf, n);
    }

    close(fd_r);
    free(temp);
    free(buf);
    unlink(argv[1]);
    exit();
}